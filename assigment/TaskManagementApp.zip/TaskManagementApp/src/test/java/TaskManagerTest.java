import javafx.scene.control.DatePicker;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import model.Task;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.testfx.framework.junit5.ApplicationTest;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class TaskManagerTest extends ApplicationTest{

    @Override
    public void start(Stage stage) throws Exception {
        new MainApp().start(stage);
    }

    // Exercise 1 - Add Task Test
    @Test
    public void testAddTaskButton_ShouldAddTaskToGUI() {
        // Simulate clicking the "Add Task" button to open the dialog
        clickOn("#addButton");

        // Enter sample information into the text fields
        clickOn("#nameField").write("New Task");
        clickOn("#descriptionField").write("New task description");
        clickOn("#statusField").clickOn("Doing");

        // Retrieve the DatePicker control
        DatePicker dueDateField = lookup("#dueDateField").queryAs(DatePicker.class);
        // Interact with UI thread to set the date value
        interact(() -> dueDateField.setValue(LocalDate.of(2023, 4, 1)));

        clickOn("#priorityField").clickOn("High");

        // Click the "Save" button to save the new task
        clickOn("#saveButton");

        sleep(1000); // sleep for 1 sec

        // Verification: Check if the task is added to the TableView
        TableView<Task> taskTable = lookup("#taskTable").queryAs(TableView.class);
        assertFalse(taskTable.getItems().isEmpty(), "Task table should not be empty after adding a task.");

        // Verify the details of the added task
        Task addedTask = taskTable.getItems().get(taskTable.getItems().size() - 1); // Assuming the new task is at the end
        assertEquals("New Task", addedTask.getName(), "Task name should match.");
        assertEquals("New task description", addedTask.getDescription(), "Task description should match.");
        assertEquals("Doing", addedTask.getStatus(), "Task status should match.");
        assertEquals("High", addedTask.getPriority(), "Task priority should match.");
        assertEquals("2023-04-01", addedTask.getDueDate().toString(), "Task due date should match.");
    }

    // Exercise 2 - ParameterizedTest of Adding a Task

    // Exercise 3 - Testing "Delete Task" button

}

